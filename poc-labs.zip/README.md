# Security Research & PoC Writeups — Sana A. Rehman

Technical writeups from hands-on penetration testing labs and boot2root challenges.
Each writeup documents the full attack chain — recon, enumeration, exploitation, and
(where applicable) privilege escalation — with screenshots and commands, structured the
same way a real engagement report is written.

Live portfolio: [sana6086.github.io](https://sana6086.github.io)

> **Scope note:** everything in this repo was performed against intentionally vulnerable
> lab environments (VulnHub-style boot2root VMs, isolated private-network labs) built for
> security training. No real organizations, production systems, or third-party data are
> involved.

---

## Writeups

| Lab | Category | Highlights |
|---|---|---|
| [Temple of Doom](./temple-of-doom) | Web App RCE → Privilege Escalation | Node.js insecure deserialization → RCE, `ss-manager` UDP exploit, `sudo tcpdump` GTFOBins privesc to root |
| [Kioptrix: Level 1](./kioptrix-1) | Network Service Exploitation | Legacy Samba `2.2.1a` `trans2open` stack buffer overflow → direct remote root |
| [ARP Spoofing / MITM Traffic Analysis](./arp-spoofing-sniffing-lab) | Network Layer Attacks | Bidirectional ARP poisoning, Wireshark traffic analysis, TLS handshake and TCP retransmission diagnostics |

---

## Methodology

All writeups follow the same structure used in professional VAPT reporting:

```
Reconnaissance → Enumeration → Attack Surface Mapping → Vulnerability Discovery
→ Manual Validation → Controlled Exploitation → Impact Assessment → Reporting & Remediation
```

Every writeup ends with a **Root Cause & Remediation** section — identifying a
vulnerability is only half the job; explaining how to fix it is the other half.

## Contact

- Email: sanarehman6086@gmail.com
- LinkedIn: [sanaabdul-rehman-6a61a8383](https://linkedin.com/in/sanaabdul-rehman-6a61a8383)
- GitHub: [sana6086](https://github.com/sana6086)
