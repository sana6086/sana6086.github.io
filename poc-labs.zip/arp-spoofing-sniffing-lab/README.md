# Man-in-the-Middle Traffic Analysis via ARP Spoofing

**Category:** Network Layer Attacks → Traffic Interception → Diagnostic Analysis
**Environment:** Local lab network (`192.168.18.0/24`)
**Attacker:** Kali Linux
**Target workstation:** `192.168.18.73` · **Gateway:** `192.168.18.1`
**Application under test:** OWASP Juice Shop (`juice-shop.herokuapp.com`)

> A practical demonstration of ARP cache poisoning used as a diagnostic
> man-in-the-middle position to capture and analyze live application traffic —
> framed here as a network health investigation, since the same technique
> that lets an attacker intercept traffic is exactly what a defender uses to
> diagnose it.

---

## Executive Summary

The goal was to diagnose intermittent connectivity disruptions affecting a workstation's
session with a web application. By positioning an attacker/diagnostic machine between the
workstation and its gateway using **bidirectional ARP poisoning**, all traffic between the
two was routed through the sniffing host for analysis. Packet capture revealed **packet loss**
and **TCP retransmissions** during the TLS handshake — pointing to a transport-layer
reliability issue rather than an application bug.

---

## 1. Intercepting Traffic — ARP Cache Poisoning

Positioned the attacking machine as a transparent man-in-the-middle by poisoning the ARP
caches of both endpoints:

**Gateway poisoning** — tell the target workstation that the attacker's MAC is the gateway:

```bash
sudo arpspoof -i eth0 -t 192.168.18.73 192.168.18.1
```

![arpspoof gateway poisoning](images/01-arpspoof-gateway-poisoning.png)

**Target poisoning** — simultaneously tell the gateway that the attacker's MAC is the
workstation:

```bash
sudo arpspoof -i eth0 -t 192.168.18.1 192.168.18.73
```

![arpspoof target poisoning](images/02-arpspoof-target-poisoning.png)

This bidirectional spoofing ensures all traffic between the workstation and the gateway
passes through the attacker for inspection, without either endpoint being aware.

## 2. Isolating Relevant Traffic — Wireshark

With traffic flowing through the intercepting host, filtered captured packets down to the
application of interest:

```
Filter: frame contains "juice"
```

Identified a **TLS 1.2 Client Hello** handshake from the workstation to
`juice-shop.herokuapp.com`, confirming the exact session under investigation.

![wireshark TLS client hello juice shop](images/03-wireshark-tls-clienthello-juiceshop.png)

## 3. Diagnostic Findings — Root Cause Analysis

Deeper inspection of the capture surfaced two consistent transport-layer symptoms:

- **Packet loss** — Wireshark repeatedly flagged `[Previous segment not captured]`,
  indicating packets were dropped in transit before reaching their destination.
- **High latency & retransmissions** — a series of `[TCP Retransmission]` events show the
  workstation resending the same segments because the network failed to deliver or
  acknowledge them the first time.

![wireshark TCP retransmission and packet loss](images/04-wireshark-retransmission-packetloss.png)

**Root cause:** these symptoms are consistent with congested network hardware or (if
applicable) wireless signal interference — either of which prevents reliable delivery of
encrypted TLS/QUIC traffic, regardless of the application itself being healthy.

## 4. Recommendations

1. **Move to wired connections** — shielded Ethernet for critical workstations eliminates
   the interference responsible for "segment not captured" errors on Wi-Fi.
2. **Upgrade network hardware** — persistent retransmissions suggest the current
   router/switch can't keep up with the processing load of modern encrypted traffic; a
   higher-throughput enterprise-grade switch is recommended.
3. **Implement QoS** — prioritize business-critical HTTPS/TLS traffic over background
   traffic at the router level to reduce contention-driven packet loss.

---

## Why This Matters (Offensive Angle)

The same ARP spoofing technique used here for diagnosis is a standard **credential and
session-hijacking vector** in a real attack: once traffic is transiting through an attacker
host, unencrypted protocols are trivially readable, and even TLS sessions can be targeted
for downgrade or certificate-pinning bypass attacks on misconfigured clients. This lab
demonstrates why networks should implement **Dynamic ARP Inspection (DAI)** and
**port security** on managed switches to prevent unauthorized ARP replies in the first place.

## Tools Used

`arpspoof` (dsniff suite) · Wireshark (capture + display filtering, TLS handshake and TCP
retransmission analysis)
